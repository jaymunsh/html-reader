import {v} from './dep.js';
window.__mod=v;
